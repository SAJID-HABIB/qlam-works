function alphabets() {
  let letters = ["k", "a", "s", "h", "a", "n", "s", "h", "a", "h", "i", "d"];
  let count = 0;
  for (let letter of letters) {
    if (
      letter === "a" ||
      letter === "e" ||
      letter === "i" ||
      letter === "o" ||
      letter === "u"
    ) {
      count++
    }
  }
  return count;
}

console.log(alphabets());
