var arr =  [1, 2, 3];
let result = mirror(arr);

function mirror(arr) {
  return arr.concat(arr.slice().reverse())
}

console.log("the resuult :",result);